const mongoose= require('mongoose')
const Schema= mongoose.Schema;

const ServerPort = new Schema({
    prevcompany:{type: String},
   years:{type: String}
},{
    collection: 'expcom'
})

module.exports= mongoose.model('expcom', ServerPort)


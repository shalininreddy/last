import React from 'react'
import Promoted1 from '../Notification/Promoted1'
import Promoted2 from '../Notification/Promoted2';
import NotificationData from './NotoficationData';
import notiDummyData from './Notification-Dummy-Data';

class Notifications extends React.Component {
    state = { notiDummyData };
    render() {
        return (
            <div class="container"> 
                <div className="row">
                    <div className="col-lg-3">
                        <Promoted1 />
                    </div>
                    <div className="col-lg-6">
                        {this.state.notiDummyData.map((noti, i) => {
                            return (
                                <NotificationData key={i} noti={noti}  />)
                        })}
                    </div>
                    <div className="col-lg-3">
                        <Promoted2 />
                    </div>
                </div>
               
            </div>
        )
    }
}

export default Notifications
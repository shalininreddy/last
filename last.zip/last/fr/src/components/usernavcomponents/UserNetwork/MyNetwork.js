
import React, {
    Component } from
    "react";
    
    import Card
    from 'react-bootstrap/Card';
    
    import { CardHeader }
    from 'reactstrap';
    
    import axios
    from 'axios';
    // import UserNavComponent from "../../../usernavcomponent";
  
    class MyNetwork extends Component {
    
    baseurl = "http://localhost:3002/Signup"
    
    constructor(props) {
    
    super(props);
    
    this.state = {
    
    loggedinuser: []
    
    
    
    };
    
    }
    
    getProfile = () => {
    
    axios.get(this.baseurl).then((response)=> {
    
    this.setState({
    email: response.data })
    
    console.log(this.state.email)
    
    this.setState({
    
    loggedinuser: 
    response.data.filter(u=> u.email !=
    sessionStorage.getItem("username"))
    
    })
    
    });
    
    }
    
    componentDidMount() {
    
    this.getProfile();
    
    console.log(this.state.loggedinuser)
    
    }
    
    render() {
    
    
    
    return (
    
    <div>
    
    {/* <UserNavComponent/> */}
    
    <div className="row">
    
    <div className="col-lg-8">
    
    <Card>
    
    <CardHeader>
    
    <h4> {this.state.loggedinuser.map((contact)=>
    
    <div>
    
    <h4 key={contact}>
    
    {/* <img
    
    src={require("../UserNetwork/pic1.jpg")}
    
    width="100px"
    
    height="100px"
    /> */}
    
    <h4>{contact.firstname}&nbsp;&nbsp;{contact.lastname}</h4>
    
    <button className="btn btn-info">Connect</button>
    
    </h4>
    
    </div>
    
    )
    
    }
    
    </h4>
    
    </CardHeader>
    
    </Card>
    
    </div>
    
    
    
    <div className="col-lg-2">
    
    <img width="280px"
    height="240px"
    src={require('./adv.jpg')}
    />
    
    </div>
    
    </div>
    
    <br /><br
    />
    
    <footer align="center">
    
    <p>YouJoin Corporation © 2019</p>
    
    </footer>
    
    </div>
    
    );
    
    }
    
    }
    
    
    
    export default
    MyNetwork;
    
    
    
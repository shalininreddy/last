import React, { Component } from 'react'
import UserNavComponent from '../usernavcomponent';
import MyNetwork from '../usernavcomponents/UserNetwork/MyNetwork';
import Profile from '../usernavcomponents/profile/profile';
export class MyProfile extends Component {
    render() {
        const signup = this.props.userData;
        return (
            <div className="backC">
                <UserNavComponent />
               <Profile/>
            </div>
        )
    }
}

export default MyProfile

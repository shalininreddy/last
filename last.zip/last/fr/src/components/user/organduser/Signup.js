import React from "react";
import axios from "axios";
import { Redirect } from "react-router";
import { Link } from "react-router-dom";

class Signup extends React.Component {
  constructor(props) {
    super(props);
    this.routeChange = this.routeChange.bind(this);
    this.onChangeFirstname = this.onChangeFirstname.bind(this);
    this.onChangeLastname = this.onChangeLastname.bind(this);
    this.onChangeType = this.onChangeType.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangePassword = this.onChangePassword.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.state = {
      firstname: "",
      lastname: "",
      userType: "",
      email: "",
      password: ""
    };
  }
  
  onChangeFirstname(e) {
    this.setState({
      firstname: e.target.value
    });
  }

  onChangeLastname(e) {
    this.setState({
      lastname: e.target.value
    });
  }
  onChangeType(e) {
    this.setState({
      userType: e.target.value
    });
  }
  onChangeEmail(e) {
    this.setState({
      email: e.target.value
    });
  }

  onChangePassword(e) {
    this.setState({
      password: e.target.value
    });
  }

  routeChange(id) {
    let path = `/Login`;
    this.props.history.push(path);
  }

  onSubmit(e) {
    e.preventDefault();
    const signup = {
      firstname: this.state.firstname,
      lastname: this.state.lastname,
      userType: this.state.userType,
      email: this.state.email,
      password: this.state.password
    };
    console.log(signup);
    axios.post("http://localhost:3002/Signup", signup).then(function (response) {
      console.log(response.data);
    });
    this.setState({
      name: "",
      status: "",
      redirect: true
    });
  }
  render() {
    const { redirect } = this.state;
    console.log("redirect value" + redirect);
    if (redirect) {
      return <Redirect to="/Login" />;
    }
    return (
      <div>
       
       <div className="container" > 
           <div className="border border-dark" align="center">
                <h2 className="text-danger">Register for Join</h2>
            {/* <h2 className="text-success">Be Great At What You Do</h2>
            <h2 className="text-info"> Get Started - It's Free</h2> */}
            <hr />
            <div align="center">
            <div className="col-lg-5" >
              <form onSubmit={this.onSubmit}  >
                <div className="form-group">
                  <label className="text-primary">
                    {" "}
                    <h3> First Name </h3>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="First Name"
                    value={this.state.firstname}
                    onChange={this.onChangeFirstname}
                    required
                  />
                </div>
                <div className="form-group">
                  <label className="text-primary">
                    <h3>Last Name </h3>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Last Name"
                    value={this.state.lastname}
                    onChange={this.onChangeLastname}
                    required
                  />
                </div>
                {/* <div className="form-group">
                  <label className="text-info">
                    <h3>User Type </h3>
                  </label> */}
                  {/* <select
                    name="dropdown"
                    value={this.state.userType}
                    onChange={this.onChangeType}
                    required
                  >
                    <option value="experience">Experience</option>
                    <option value="student">Student</option>
                  </select> */}
                {/* </div> */}
                <div className="form-group">
                  <label className="text-primary">
                    <h3>Email </h3>
                  </label>
                  <input
                    type="email"
                    className="form-control"
                    placeholder="Email"
                    value={this.state.email}
                    onChange={this.onChangeEmail}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="text-primary">
                    <h3>Password </h3>
                  </label>
                  <input
                    type="password"
                    className="form-control"
                    placeholder="Password"
                    value={this.state.password}
                    onChange={this.onChangePassword}
                    required
                  />
                </div>
                <br />
                <div className="form-group">
                  <input
                    type="submit"
                    value="Join Now"
                    className="btn btn-success"
                  />
                </div>
                <h3>Already on YouJoin ? <Link to="/Login">Sign in</Link></h3>
              </form>
            </div>
            </div>
            </div>
          </div>
          <hr/>
       </div>
    );
  }
}

export default Signup;
